import{l as o,a as r}from"../chunks/GziYSlmd.js";export{o as load_css,r as start};
