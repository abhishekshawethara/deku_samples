import{l as o,a as r}from"../chunks/Bh7MOdNg.js";export{o as load_css,r as start};
